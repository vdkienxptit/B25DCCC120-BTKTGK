import { useState, useEffect, type FormEvent } from "react";

// Kiểu dữ liệu của bài viết
type BaiViet = {
  id: number;
  userId: number;
  title: string;
  body: string;
};

// Kiểu dữ liệu của bình luận
type BinhLuan = {
  id: number;
  name: string;
  email: string;
  body: string;
};

const diaChiAPI = "https://jsonplaceholder.typicode.com";

// Đọc các bài viết đã lưu trong trình duyệt
function layBaiVietDaLuu(): BaiViet[] {
  try {
    return JSON.parse(localStorage.getItem("baiVietMoi") || "[]") as BaiViet[];
  } catch {
    return [];
  }
}

// Trang chủ
function TrangChu() {
  const [danhSach, setDanhSach] = useState<BaiViet[]>([]);
  const [tuKhoa, setTuKhoa] = useState("");
  const [dangTai, setDangTai] = useState(true);
  const [loi, setLoi] = useState("");

  useEffect(() => {
    async function layDanhSach() {
      try {
        const phanHoi = await fetch(diaChiAPI + "/posts");
        if (!phanHoi.ok) throw new Error("Lỗi tải dữ liệu");

        const duLieu: BaiViet[] = await phanHoi.json();
        setDanhSach([...layBaiVietDaLuu(), ...duLieu]);
      } catch {
        setDanhSach(layBaiVietDaLuu());
        setLoi("Không kết nối được máy chủ. Hãy kiểm tra Internet.");
      } finally {
        setDangTai(false);
      }
    }

    layDanhSach();
  }, []);

  const ketQua = danhSach.filter((bai) =>
    bai.title.toLowerCase().includes(tuKhoa.toLowerCase())
  );

  return (
    <main>
      <h2>Danh sách bài viết</h2>
      <p>Tìm bài viết theo tiêu đề.</p>

      <input
        value={tuKhoa}
        onChange={(e) => setTuKhoa(e.target.value)}
        placeholder="Nhập tiêu đề cần tìm..."
      />

      {dangTai && <p>Đang tải bài viết...</p>}
      {loi && <p className="thong-bao">{loi}</p>}
      {!dangTai && ketQua.length === 0 && <p>Không tìm thấy bài viết.</p>}

      {ketQua.map((bai) => (
        <article className="bai-viet" key={bai.id}>
          <h3>
            <a href={"/bai-viet/" + bai.id}>{bai.title}</a>
          </h3>
          <p>{bai.body}</p>
          <a href={"/bai-viet/" + bai.id}>Đọc chi tiết</a>
        </article>
      ))}
    </main>
  );
}

// Chi tiết bài viết và bình luận
function ChiTietBaiViet({ id }: { id: number }) {
  const [baiViet, setBaiViet] = useState<BaiViet | null>(null);
  const [danhSachBinhLuan, setDanhSachBinhLuan] = useState<BinhLuan[]>([]);
  const [dangTai, setDangTai] = useState(true);
  const [loi, setLoi] = useState("");

  useEffect(() => {
    async function layChiTiet() {
      try {
        const baiDaLuu = layBaiVietDaLuu().find((bai) => bai.id === id);
        let duLieuBai: BaiViet;

        if (baiDaLuu) {
          duLieuBai = baiDaLuu;
        } else {
          const phanHoi = await fetch(diaChiAPI + "/posts/" + id);
          if (!phanHoi.ok) throw new Error("Không tìm thấy bài viết");
          duLieuBai = await phanHoi.json();
        }

        setBaiViet(duLieuBai);

        if (baiDaLuu) {
          setDanhSachBinhLuan([]);
        } else {
          const phanHoiBinhLuan = await fetch(
            diaChiAPI + "/posts/" + id + "/comments"
          );
          if (!phanHoiBinhLuan.ok) throw new Error("Không tải được bình luận");

          const duLieuBinhLuan: BinhLuan[] = await phanHoiBinhLuan.json();
          setDanhSachBinhLuan(duLieuBinhLuan);
        }
      } catch {
        setLoi("Không tải được bài viết. Vui lòng thử lại.");
      } finally {
        setDangTai(false);
      }
    }

    layChiTiet();
  }, [id]);

  if (dangTai) return <main><p>Đang tải bài viết...</p></main>;

  if (loi || !baiViet) {
    return (
      <main>
        <h2>Không tìm thấy bài viết</h2>
        <p>{loi}</p>
        <a href="/">Quay về trang chủ</a>
      </main>
    );
  }

  return (
    <main>
      <a href="/">← Quay về trang chủ</a>
      <h2>{baiViet.title}</h2>
      <p>{baiViet.body}</p>
      <h3>Danh sách bình luận</h3>

      {danhSachBinhLuan.length === 0 && <p>Bài viết này chưa có bình luận.</p>}

      {danhSachBinhLuan.map((binhLuan) => (
        <article className="binh-luan" key={binhLuan.id}>
          <h4>{binhLuan.name}</h4>
          <p>{binhLuan.email}</p>
          <p>{binhLuan.body}</p>
        </article>
      ))}
    </main>
  );
}

// Đăng nhập
function DangNhap() {
  const [taiKhoan, setTaiKhoan] = useState("");
  const [matKhau, setMatKhau] = useState("");
  const [loi, setLoi] = useState("");

  function xuLyDangNhap(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (taiKhoan === "admin" && matKhau === "123456") {
      localStorage.setItem("daDangNhap", "co");
      window.location.href = "/viet-bai";
    } else {
      setLoi("Sai tài khoản hoặc mật khẩu.");
    }
  }

  return (
    <main>
      <h2>Đăng nhập</h2>
      <p>Tài khoản mẫu: admin</p>
      <p>Mật khẩu mẫu: 123456</p>

      <form onSubmit={xuLyDangNhap}>
        <label>Tên tài khoản</label>
        <input
          value={taiKhoan}
          onChange={(e) => setTaiKhoan(e.target.value)}
          required
        />

        <label>Mật khẩu</label>
        <input
          type="password"
          value={matKhau}
          onChange={(e) => setMatKhau(e.target.value)}
          required
        />

        {loi && <p className="thong-bao">{loi}</p>}
        <button type="submit">Đăng nhập</button>
      </form>
    </main>
  );
}

// Viết bài mới
function VietBai() {
  const [tieuDe, setTieuDe] = useState("");
  const [noiDung, setNoiDung] = useState("");
  const [loi, setLoi] = useState("");

  if (localStorage.getItem("daDangNhap") !== "co") {
    return (
      <main>
        <h2>Bạn cần đăng nhập để viết bài.</h2>
        <a href="/dang-nhap">Đi đến trang đăng nhập</a>
      </main>
    );
  }

  function xuLyDangBai(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (tieuDe.trim().length < 3) {
      setLoi("Tiêu đề phải có ít nhất 3 ký tự.");
      return;
    }

    if (noiDung.trim().length < 10) {
      setLoi("Nội dung phải có ít nhất 10 ký tự.");
      return;
    }

    const baiMoi: BaiViet = {
      id: Date.now(),
      userId: 1,
      title: tieuDe.trim(),
      body: noiDung.trim()
    };

    localStorage.setItem(
      "baiVietMoi",
      JSON.stringify([baiMoi, ...layBaiVietDaLuu()])
    );

    alert("Đăng bài thành công!");
    window.location.href = "/";
  }

  function xuLyDangXuat() {
    localStorage.removeItem("daDangNhap");
    window.location.href = "/dang-nhap";
  }

  return (
    <main>
      <h2>Viết bài mới</h2>
      <button type="button" onClick={xuLyDangXuat}>Đăng xuất</button>

      <form onSubmit={xuLyDangBai}>
        <label>Tiêu đề bài viết</label>
        <input
          value={tieuDe}
          onChange={(e) => setTieuDe(e.target.value)}
          placeholder="Nhập tiêu đề..."
          required
        />

        <label>Nội dung bài viết</label>
        <textarea
          value={noiDung}
          onChange={(e) => setNoiDung(e.target.value)}
          placeholder="Nhập nội dung..."
          rows={6}
          required
        />

        {loi && <p className="thong-bao">{loi}</p>}
        <button type="submit">Đăng bài</button>
      </form>
    </main>
  );
}

// Trang 404
function Trang404() {
  return (
    <main>
      <h1>404</h1>
      <h2>Không tìm thấy trang</h2>
      <a href="/">Quay về trang chủ</a>
    </main>
  );
}

// Ứng dụng chính
function App() {
  const duongDan = window.location.pathname;
  let noiDung = <Trang404 />;

  if (duongDan === "/") {
    noiDung = <TrangChu />;
  } else if (duongDan === "/dang-nhap") {
    noiDung = <DangNhap />;
  } else if (duongDan === "/viet-bai") {
    noiDung = <VietBai />;
  } else if (duongDan.startsWith("/bai-viet/")) {
    const id = Number(duongDan.split("/")[2]);
    noiDung = Number.isInteger(id) && id > 0
      ? <ChiTietBaiViet id={id} />
      : <Trang404 />;
  }

  return (
    <div className="khung">
      <header>
        <h1>MiniBlog</h1>
        <nav>
          <a href="/">Trang chủ</a>
          <a href="/dang-nhap">Đăng nhập</a>
          <a href="/viet-bai">Viết bài</a>
        </nav>
      </header>

      {noiDung}

      <footer>MiniBlog - Bài tập React + TypeScript</footer>
    </div>
  );
}

export default App;
